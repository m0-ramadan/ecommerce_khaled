<noscript><iframe src="https://www.googletagmanager.com/ns.html?id=GTM-TGFC6FV" height="0" width="0"
        style="display:none;visibility:hidden"></iframe></noscript>
<div class="s-advertisement" data-id="1925582479" style="background-color: rgb(0, 0, 0); color: rgb(255, 255, 255);">
    <div class="s-advertisement-content">
        <h2 class="s-advertisement-content-main"><i class="s-advertisement-content-icon sicon-bell"></i>كل اللي تحتاجه من
            مطبوعات تالا الجزيرة متوفر وبتصميمك الخاص</h2><button class="s-advertisement-action"
            aria-label="close-alert"><i class="sicon-cancel"></i></button>
    </div>
</div>
<header class="store-header">
    <div class="top-nav">
        <div class="container">
            <div class="top-nav-inner center-between relative">
                <div class="right-side flex justify-between lg:justify-start grow max-w-full">
                    <div class="flex items-center -mx-1 max-w-[calc(100%-120px)] overflow-hidden">
                        <button type="button"
                            onclick="if (!window.__cfRLUnblockHandlers) return false; salla.event.dispatch('localization::open')"
                            class="btn--gray rounded mx-1" data-cf-modified-9a2cfb1b0771358ad3b1a4ee-="">
                            <span class="flag iti__flag iti__sa rtl:ml-1.5 ltr:mr-1.5 rounded-sm"></span>
                            | <span class="rtl:mr-2 ltr:ml-2 rtl:ml-1 ltr:mr-1"><i class=sicon-sar></i></span>
                        </button>
                    </div>
                    <div class="flex items-center gap-6 rtl:sm:mr-10 ltr:sm:ml-10">
                        <a href="mailto:support@talaaljazira.co"
                            class="s-contacts-topnav-link">support@talaaljazira.co</a>
                        <a class="topnav-link-item header-search-trigger">
                            <i class="sicon-search"></i>
                        </a>
                    </div>
                </div>
                <div class="left-side grow hidden lg:block">
                    <div>
                        <div class="s-menu-topnav-list"><a href="#" target="_self"
                                class="s-menu-topnav-item topnav-link-item right-side">سياسة
                                الخصوصية</a><a href="#" target="_self"
                                class="s-menu-topnav-item topnav-link-item right-side">لا تستطيع الوصول
                                للمنتج؟ ( قاموس البحث هنا )</a><a href="#" target="_self"
                                class="s-menu-topnav-item topnav-link-item right-side">الأسئلة الشائعة</a></div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div id="mainnav" class="main-nav-container">
        <div class="inner bg-inherit">
            <div class="container sides-wrap">
                <div class="right-side flex items-center lg:grow">
                    <a class="navbar-brand" href="#">
                        <img src="{{ asset('website/images/tala,.png') }}" alt="Tala Aljazira">
                        <h1 class="sr-only">تالا الجزيرة</h1>
                    </a>
                    <div class="flex items-center rtl:lg:mr-16 ltr:lg:ml-16 grow -order-1 lg:order-2">
                        <button data-nav="btn" class="humb menu-trigger" aria-label="menu">
                            <span class="humb-icon">
                                <span></span>
                                <span></span>
                                <span></span>
                                <span></span>
                            </span>
                        </button>
                        <div class="search-bar">
                            <salla-search inline height="46"></salla-search>
                        </div>
                    </div>
                </div>
                <div class="left-side flex items-center justify-center lg:justify-end px-4 lg:px-0">
                    <div class="hidden lg:flex">
                        <a class="header-icon-button"
                            onclick="if (!window.__cfRLUnblockHandlers) return false; salla.event.dispatch('login::open')"
                            data-cf-modified-9a2cfb1b0771358ad3b1a4ee-="">
                            <i class="icon sicon-user"></i>
                            <div class="hidden lg:flex flex-col leading-none text-sm">
                                <p class="opacity-50 mb-1 ">حسابي</p>
                                <span class="flex leading-none text-sm ">تسجيل الدخول</span>
                            </div>
                        </a>
                    </div>
                </div>
            </div>
            <nav id="side-panel" class="side-panel">
                <div class="flex lg:hidden">
                    <a class="header-icon-button w-full text-white"
                        onclick="if (!window.__cfRLUnblockHandlers) return false; salla.event.dispatch('login::open')"
                        data-cf-modified-9a2cfb1b0771358ad3b1a4ee-="">
                        <i class="icon sicon-user"></i>
                        <div class="text">
                            <span>حسابي</span>
                            <span>تسجيل الدخول</span>
                        </div>
                        <span class="sicon-keyboard_arrow_left rtl:mr-auto ltr:ml-auto"></span>
                    </a>
                </div>
                <div>
                    <ul class="main-menu">
                        <li class="root-level" id="blog">
                            <a target="_self" class="blog-link" href="#" class="collapsible-title">
                                <span>المدونة</span>
                            </a>
                        </li>
                        <li class="root-level" id="368078986">
                            <a target="_self" href="#" class="collapsible-title">
                                <span>كل المنتجات</span>
                            </a>
                        </li>
                        <li class="root-level" id="1357117963">
                            <a target="_self" href="#" class="collapsible-title">
                                <span>عروض البكجات</span>
                            </a>
                        </li>
                        <li class="root-level data-collapsible mobile-accordion has-children" id="832013053">
                            <a target="_self" href="#" class="collapsible-title" trigger="mobile-collapsible">
                                <span>طباعة الملصقات والاستيكرات</span>
                            </a>
                            <div class="mobile-collapsible sub-menu">
                                <ul>
                                    <li class="xl:hidden">
                                        <a target="_self" href="#">
                                            <span>عرض الكل</span>
                                        </a>
                                    </li>
                                    <li id="1719776338">
                                        <a target="_self" href="#" class="collapsible-title">
                                            <span>استيكرات الشحن والاغلاق</span>
                                        </a>
                                    </li>
                                    <li id="987657808">
                                        <a target="_self" href="#" class="collapsible-title">
                                            <span>استيكرات مربعة</span>
                                        </a>
                                    </li>
                                    <li id="1760646999">
                                        <a target="_self" href="#" class="collapsible-title">
                                            <span>استيكرات دائرية</span>
                                        </a>
                                    </li>
                                </ul>
                            </div>
                        </li>

                        <li class="root-level" id="1002461499">
                            <a target="_self" href="#" class="collapsible-title">
                                <span>خدمات التصميم</span>
                            </a>
                        </li>
                        <li class="root-level" id="brands">
                            <a target="_self" class="brands-link" href="#" class="collapsible-title">
                                <span></span>
                            </a>
                        </li>
                    </ul>
                </div>
            </nav>
        </div>
    </div>
</header>
