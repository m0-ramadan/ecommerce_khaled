@include('admin.layout.header1')
@include('admin.layout.navbar')
    @yield('content')
@include('admin.layout.footer1')

