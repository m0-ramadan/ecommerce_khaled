
@include('admin.other_users.layouts.sales_management.header')
 
 @include('admin.other_users.layouts.sales_management.navbar')


    @yield('content')



@include('admin.other_users.layouts.sales_management.footer')

