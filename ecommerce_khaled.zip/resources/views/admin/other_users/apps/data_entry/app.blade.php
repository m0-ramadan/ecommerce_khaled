
@include('admin.other_users.layouts.header')

 

    @yield('content')



@include('admin.other_users.layouts.footer')

