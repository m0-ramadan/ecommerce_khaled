<div class="col-6 box-col-3 des-xl-25 rate-sec">
    <div class="card income-card card-primary">
        <a href="{{ $route }}">
            <div class="card-body text-center">
                <div class="round-box">
                    <i data-feather="box"></i>
                </div>
                <h5>{{ $title }}</h5>
            </div>
    </div>
    </a>
</div>
