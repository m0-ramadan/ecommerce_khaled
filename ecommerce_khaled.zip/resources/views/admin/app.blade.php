
@include('admin.layout.header')

@include('admin.layout.navbar')


    @yield('content')



@include('admin.layout.footer')

