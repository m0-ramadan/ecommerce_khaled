<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Category;
use App\Models\Image;
use App\Models\MetaTag;
use App\Models\Product;
use App\Models\Store;
use App\Models\SubCategory;
use Illuminate\Http\Request;
use Auth;

class ProductController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $products = Product::Active()->get();
        $categories = Category::get();
        $subcategories = SubCategory::get();
        $stores = Store::get();
       
        return view('admin.products.index',compact(['products','categories','subcategories','stores']));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $subcategories= SubCategory::where('is_active',1)->get();
        $categories = Category::where('is_active',1)->get();
        $stores = Store::where('is_active',1)->get();
        return view('admin.products.add',compact(['subcategories','categories','stores']));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        if ($request->hasFile('image')) {
            
                $imageNameToStore = uploadImage('product',$request->image);
        }
        $validatedData = $request->validate([
            'name_ar'                          => 'required',
            'details_ar'                       => 'required',
            'current_price'                            => 'required|numeric',
            'quantity'                         => 'required|numeric',
            'category_id'                      => 'required',
            ]);


        $product = new Product;
        $product->name                            = ['en'=>$request->name_en,'ar'=>$request->name_ar,'it'=>$request->name_it];
        $product->name_search                     = $request->name_en.','.$request->name_ar.','.$request->name_it;
        $product->details                         = ['en'=>$request->details_en,'ar'=>$request->details_ar,'it'=>$request->details_it];
        $product->title_img                           = $request->img_title;
         $product->alt_text                           = $request->alt_title;
          $product->slug                           = $request->slug;
           $product->serial_no                      = $request->serail_no;
         $product->tax_amount                      = $request->tax_amount;
        $product->smart_price                      = $request->smart_price;
         $product->old_price                           = $request->old_price;
         
        $product->current_price                        = $request->current_price;
        $product->quantity                        = $request->quantity;
        $product->category_id                     = $request->category_id;
        $product->sub_category_id                 =$request->sub_category_id ?? null;
        $product->image                           = $imageNameToStore ?? null;
        $product->save();


        if ($request->hasFile('images')) 
        {
            $images=$request->file('images'); 
            foreach($images as $key=> $image)
            { 
                
                   $filename = time(). $key.'.' .$image->extension();
                   $fileNameToStore = uploadImages($image,'product',$filename);
                    $imagenew = Image::create([
                    'product_id'       =>$product->id,
                    'src'               =>$fileNameToStore,
                ]);
            }
        }
        else
        {
            $image = Image::create([
                'product_id'       =>$product->id,
                'src'              =>Null,
            ]);
        }

        $metaTags = new MetaTag;
        $metaTags->product_id                   = $product->id;
        $metaTags->text                         = $product->details;
        $metaTags->save();

        toastr()->success('تم اضافة المنتج بنجاح');
        return redirect('admin/product');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
       $product = Product::findOrFail($request->id);
       
        if ($request->hasFile('image')) {
                
                $imageNameToStore = uploadImage('product',$request->image);
                
               
        }
       
         if ($request->hasFile('images')) {

            $oldimages=Image::where('product_id',$id)->get();
            
            foreach($oldimages as $oldimage){
              $oldimage->delete();
              
 
            } 
           $images=$request->file('images'); 
            foreach($images as $key=> $image)
            { 
                
                   $filename = time(). $key.'.' .$image->extension();
                   $fileNameToStore = uploadImages($image,'product',$filename);
                    $imagenew = Image::create([
                    'product_id'       =>$product->id,
                    'src'               =>$fileNameToStore,
                ]);
            }
        }
        $product->update([
            $product->name                            = ['en'=>$request->name_en,'ar'=>$request->name_ar,'it'=>$request->name_it],
            $product->details                         = ['en'=>$request->details_en,'ar'=>$request->details_ar,'it'=>$request->details_it],
            $product->old_price                           = $request->old_price,
            $product->current_price                        = $request->current_price,
            $product->title_img                           = $request->img_title,
         $product->alt_text                           = $request->alt_title,
          $product->slug                           = $request->slug,
           $product->serial_no                      = $request->serail_no,
         $product->tax_amount                      = $request->tax_amount,
           
        $product->smart_price                      = $request->smart_price,
            $product->quantity                        = $request->quantity,
            $product->category_id                     = $request->category_id,
            $product->sub_category_id                 =$request->sub_category_id ?? null,
            $product->image                           =  ($request->has('image')) ? $imageNameToStore : $product->image ,
        ]);
        toastr()->success('تم التعديل بنجاح');
        return back();
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy(Request $request)
    {
        $product = Product::findOrFail($request->id);
        if ($product)
        {
            $product->is_Active=false;
            $product->save();
        }
        toastr()->error('تم حذف المنتج بنجاح');
        return redirect('admin/product');
    }
}
