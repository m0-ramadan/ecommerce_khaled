<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Contact;
use Illuminate\Http\Request;

class SettingController extends Controller
{
    public function settings()
    {
        $settings = Contact::first();
        return view('admin.settings.index',compact('settings'));
    }

    public function settingsSave(Request $request)
    {
        $validatedData = $request->validate([
            'facebook'                 => 'required',
            'twitter'                  => 'required',
            'instagram'                => 'required',
            'phone'                    => 'required',
            'address'                  => 'required',
            'location'                 => 'required',
            'app_name'                 => 'required',
        ]);
            $setting = Contact::first();
            if ($request->hasfile('image')) {
                $filepath = uploadImage('settings',$request->image);
                $setting->update([
                    'image'   => $filepath,
                ]);
            }
            
            $setting = Contact::first();
            if ($request->hasfile('video_link')) {
                $filepath = uploadImage('settings',$request->video_link);
                $setting->update([
                    'video_link'   => $filepath,
                ]);
            }

            $setting = Contact::first();
            if ($request->hasfile('head_image')) {
                $filepath = uploadImage('settings',$request->head_image);
                $setting->update([
                    'head_image'   => $filepath,
                ]);
            }

            $setting = Contact::first();
            if ($request->hasfile('bottom_image')) {
                $filepath = uploadImage('settings',$request->bottom_image);
                $setting->update([
                    'bottom_image'   => $filepath,
                ]);
            }

            $setting = Contact::first();
            if ($request->hasfile('offer_image')) {
                $filepath = uploadImage('settings',$request->offer_image);
                $setting->update([
                    'offer_image'   => $filepath,
                ]);
            }

            if ($request->hasfile('insp_mop_img')) {
                $filepath = uploadImage('settings',$request->insp_mop_img);
                $setting->update([
                    'insp_mop_img'   => $filepath,
                ]);
            }

            if ($request->hasfile('insp_web_img')) {
                $filepath = uploadImage('settings',$request->insp_web_img);
                $setting->update([
                    'insp_web_img'   => $filepath,
                ]);
            }

                $setting->facebook                     =$request->facebook;
                $setting->twitter                      =$request->twitter;
                $setting->instagram                    =$request->instagram;
                $setting->youtube                      =$request->youtube;
                $setting->tiktok                       =$request->tiktok;
                $setting->phone                        =$request->phone;
                $setting->address                      =$request->address;
                $setting->location                     =$request->location;
                $setting->details                      =$request->details;
                $setting->replacement                  =$request->replacement;
                $setting->judgments                    =$request->judgments;
                $setting->app_name                     =$request->app_name;
                $setting->head_color                   =$request->head_color;
                $setting->font_color                   =$request->font_color;
                $setting->home_head_color               =$request->home_head_color;
                $setting->home_font_color               =$request->home_font_color;
            $setting->save();
        toastr()->success('success');
        return redirect('admin/setting');
    }
}
