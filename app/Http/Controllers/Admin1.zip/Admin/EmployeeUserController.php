<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\User;
use Illuminate\Support\Facades\Hash;

use Illuminate\Http\Request;

class EmployeeUserController extends Controller
{
    // public function archiveProduct()
    // {
    //     $archiveProducts = Product::where(['is_active'=>false])->get();
    //     return view('admin.archives.product',compact('archiveProducts'));
    // }

    // public function archiveRestore(Request $request)
    // {
    //     $restoreProduct = Product::findOrFail($request->id);
    //     $cate = Category::where([
    //         ['id',$restoreProduct->category_id],
    //         ['is_active',true]
    //     ])->first();
    //     $sub = SubCategory::where([
    //         ['id',$restoreProduct->sub_category_id],
    //         ['is_active',true]
    //     ])->first();
    //     if($cate)
    //     {
    //         $restoreProduct->is_active=true;
    //         $restoreProduct->save();
    //         toastr()->success('تم استعادة المنتج بنجاح');
    //     }else{
    //         toastr()->error('هذا المنتج غير تابع لقسم رئيسي او قسم فرعي مفعل يرجي التاكد من القسم التابع له هذا المنتج');
    //     }
    //     return back();
    // }

    public function index()
    {
        $employees = User::get(); 
          $arr =[
       ' super admin' ,
       ' دعم فني '   ,
       '  ادارة المبيعات و التسويق و العمولة ',
       '  دعم فني و مدخل بيانات',
       '    شريك استثماري',
];
        return view('admin.employees.index',compact('employees' , 'arr'));
    }
    
        public function show($id)
    {
        $employee = User::find($id);
        return view('admin.employees.add',compact('employee'));

     }
    
    public function create()
    {
        
     }
     
         public function store(Request $request)
    {
        
        User::create([
             'name' => $request->name,
             'email'=> $request->email,
             'password' => Hash::make($request->password),
            //  'remember_token' => $request->hhhh,
             'firebase_id' => $request->firebase_id,
            'phone' => $request->phone,
             'txt'  => $request->txt,
             'device_key' => $request->device_key,
                          'type' => $request->type,

            ]);
            return redirect()->route('employees.index');
     }

     
    
    
    public function edit(Request $request)
    {
     }

     
        public function update( $id , Request $request)
    {
           $user = User::find( $id);
           $user->update([
                 'name' => $request->name,
                 'email'=> $request->email,
                 'firebase_id' => $request->firebase_id,
                 'phone' => $request->phone,
                 'txt'  => $request->txt,
                 'device_key' => $request->device_key,
                 'type'  => $request->type,
    
                ]);
                if(isset($request->password)){
                          $user->password = Hash::make($request->password);
                          $user->save();
                }
            
                        return redirect()->back();

    }
    

    public function destroy()
    {
     }



}
