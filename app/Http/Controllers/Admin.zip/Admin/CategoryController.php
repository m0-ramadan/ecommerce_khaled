<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Category;
use App\Models\Product;
use App\Models\Store;
use App\Models\SubCategory;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Notification;

class CategoryController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $categories = Category::where(['is_active'=>true])->get();
        $stores = Store::get();

        return view('admin.categories.index',compact(['categories','stores']));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $stores = Store::get();
        return view('admin.categories.add',compact('stores'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $validatedData = $request->validate([
            'name_ar'                 => 'required',
            'description_ar'          => 'required',
            'store_id'                => 'required',
        ]);
        if ($request->hasFile('image')){
            $fileNameToStore = uploadImage('category',$request->image);
        }else {
            $fileNameToStore = 'images/zummXD2dvAtI.png';
        }

        if ($request->hasFile('image_mop')){
            $fileNameToStoreMop = uploadImage('category',$request->image_mop);
        }else {
            $fileNameToStoreMop = 'images/zummXD2dvAtI.png';
        }

        $category = new Category;
        $category->name                = ['en'=>$request->name_en,'ar'=>$request->name_ar,'it'=>$request->name_it];
        $category->description         = ['en'=>$request->description_en,'ar'=>$request->description_ar,'it'=>$request->description_it];
        $category->store_id            =$request->store_id;
        $category->image               = $fileNameToStore;
        $category->image_mop           = $fileNameToStoreMop;
        $category->cat_title            =$request->cat_title;
        $category->cat_meta            =$request->cat_meta;
        $category->alt_txt            =$request->alt_txt;
        $category->img_title            =$request->img_title;
        $category->slug            =$request->slug;

        
        
        
        $category->save();
        toastr()->success('تمت الاضافة بنجاح');

        return redirect('admin/category');

    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        
            $category = Category::findOrFail($request->id);

            if ($request->hasfile('image')) {
                $filepath = uploadImage('category',$request->image);
                $category->update([
                    'image'   => $filepath,
                ]);
            }
            if ($request->hasfile('image_mop')) {
                $filepathMop = uploadImage('category',$request->image_mop);
                $category->update([
                    'image_mop'   => $filepathMop,
                ]);
            }
            $category->update([
                $category->name                 =  ['en'=>$request->name_en,'ar'=>$request->name_ar,'it'=>$request->name_it],
                $category->description          =  ['en'=>$request->description_en,'ar'=>$request->description_ar,'it'=>$request->description_it],
                $category->cat_title            =$request->cat_title,
                $category->cat_meta             =$request->cat_meta,
                $category->alt_txt              =$request->alt_txt,
                $category->img_title            =$request->img_title,
                $category->slug                 =$request->slug,
            ]);
  if( $request->store_id!=""){
      $category->update([ $category->store_id=  $request->store_id]);
  }

        toastr()->success('تم التعديل بنجاح');
        return redirect('admin/category');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy(Request $request)
    {
        $category = Category::findOrFail($request->id);
        if($category){
            $category->is_active=false;
            $category->save();
            $subcategories = SubCategory::where('category_id',$request->id)->get();
            foreach ($subcategories as $sucategory)
            {
                $sucategory->is_active=false;
                $sucategory->save();
            }

            $products = Product::where('category_id',$request->id)->get();
            foreach ($products as $product)
            {
                $product->is_active=false;
                $product->save();
            }
            toastr()->error('تم الحذف بنجاح');
        }else{
            toastr()->error('هذا القسم غير موجود');
        }


        return redirect('admin/category');
    }

    public function subcats(Request $request)
    {
        $data   = [];
        $subcats = SubCategory::where([
            ['category_id',$request->cat],
            ['is_active',true]
        ])->get();

        foreach( $subcats as  $stat){
            if( $stat->category_id != $request->cat){
                return response()->json('<option >لاتوجد بيانات</option>') ;
            }
            $data[] = '<option  value="'.$stat->id.'">'. $stat->name .'</option>';
        }
        return response()->json(["data" => $data]) ;
    }
}
