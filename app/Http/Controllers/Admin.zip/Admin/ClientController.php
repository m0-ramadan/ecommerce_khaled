<?php

namespace App\Http\Controllers\Admin;
use App\Traits\FcmNotificationTrait;
use App\Traits\SendNotificationTrait;
use App\Http\Controllers\Controller;
use App\Models\Client;
use App\Models\ClientsToken;
use Illuminate\Http\Request;

class ClientController extends Controller
{
    
    use FcmNotificationTrait;
    use SendNotificationTrait;
    
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $clients = \App\Models\Client::get();
        return view('admin.clients.index',compact('clients'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy(Request $request)
    {
        $client = \App\Models\Client::findOrFail($request->id)->delete();
        return back();
    }

    public function sendNotification(Request $request)
    {
        
       
        
        $token_app = Client::find($request->id);
          echo $request->id;
        $clients_token = ClientsToken::where("id_client",$request->id)->get();
        $result = sendmessage($request->title, $request->body,'',$request->id);
        foreach($clients_token as $app_token){
          $this->sendNotify('new Order created ',"test",$app_token->firebase_id);
        }
        toastr()->success('تم ارسال الاشعار بنجاح');
         return back();
    }
}
